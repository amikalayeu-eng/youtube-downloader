from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_frontend_has_required_controls_and_no_heavy_framework():
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    assert 'id="youtube-url"' in html
    assert all(f'data-format="{x}"' in html for x in ("mp3", "wav", "video"))
    assert all(f'data-quality="{x}"' in html for x in ("low", "medium", "maximum"))
    assert 'No fake percentage' in js
    assert 'react' not in html.lower()


def test_mobile_css_avoids_fixed_wide_layout():
    css = (ROOT / "frontend" / "styles.css").read_text(encoding="utf-8")
    assert '@media' in css
    assert '320' in css or '360' in css
    assert 'overflow-x' in css
