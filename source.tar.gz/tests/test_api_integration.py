"""Runs fully inside the Docker test profile with real Redis/RQ and fake media work."""
import os
import time

import pytest

redis = pytest.importorskip("redis")
pytest.importorskip("rq")
from fastapi.testclient import TestClient

from app.api import app
from app.config import settings

pytestmark = pytest.mark.skipif(os.getenv("RUN_REDIS_INTEGRATION") != "1", reason="requires Docker Redis + fake worker")


def wait_json(client, path, terminal=("ready", "failed"), timeout=8):
    end = time.time() + timeout
    last = None
    while time.time() < end:
        last = client.get(path)
        assert last.status_code == 200, last.text
        body = last.json()
        if body["status"] in terminal:
            return body
        time.sleep(0.08)
    raise AssertionError(f"Timed out: {last.text if last else path}")


def test_full_analyze_job_status_and_file_flow():
    assert settings.load_test_fake_media is True
    redis.Redis.from_url(settings.redis_url).flushdb()
    with TestClient(app) as client:
        a = client.post("/api/analyze", json={"url": "https://youtu.be/dQw4w9WgXcQ"})
        assert a.status_code == 202
        analyzed = wait_json(client, f"/api/analyze/{a.json()['id']}")
        assert analyzed["title"] == "Load Test Video"
        j = client.post("/api/jobs", json={"analysis_id": a.json()["id"], "format": "mp3", "quality": "maximum"})
        assert j.status_code == 202
        ready = wait_json(client, f"/api/jobs/{j.json()['id']}")
        assert ready["download_url"]
        f = client.get(ready["download_url"])
        assert f.status_code == 200
        assert b"AUDIOERA LOAD TEST" in f.content


def test_invalid_url_and_invalid_job_are_bounded_errors():
    with TestClient(app) as client:
        assert client.post("/api/analyze", json={"url": "https://example.com/no"}).status_code == 400
        assert client.get("/api/jobs/j_missing").status_code in (403, 404)
