import pytest

from app.security import normalize_youtube_url, safe_filename, safe_thumbnail


@pytest.mark.parametrize("raw", [
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtu.be/dQw4w9WgXcQ?t=12",
    "https://youtube.com/shorts/dQw4w9WgXcQ",
    "https://m.youtube.com/watch?v=dQw4w9WgXcQ&list=abc",
])
def test_single_video_urls_normalize(raw):
    assert normalize_youtube_url(raw) == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"


@pytest.mark.parametrize("raw", [
    "https://example.com/watch?v=dQw4w9WgXcQ",
    "file:///etc/passwd",
    "https://youtube.com/playlist?list=PL123",
    "https://youtube.com/@channel",
    "https://youtube.com/watch?v=bad",
    "https://user:pass@youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtube.com:444/watch?v=dQw4w9WgXcQ",
    "https://youtube.com:notaport/watch?v=dQw4w9WgXcQ",
    "https://youtube.com/watch?v=dQw4w9WgXcQ;rm+-rf+/",
])
def test_non_video_or_abusive_urls_are_rejected(raw):
    with pytest.raises(ValueError):
        normalize_youtube_url(raw)


def test_filename_blocks_path_traversal_and_controls():
    value = safe_filename('../../evil\\name:\x00?.mp3')
    assert '/' not in value and '\\' not in value and '\x00' not in value
    assert len(value.encode('utf-8')) <= 180


def test_unicode_filename_is_utf8_bounded():
    value = safe_filename('Музыка 🎵 ' * 100)
    assert 0 < len(value.encode('utf-8')) <= 180


def test_thumbnail_allowlist():
    assert safe_thumbnail('https://i.ytimg.com/vi/abc/default.jpg')
    assert safe_thumbnail('https://img.youtube.com/vi/abc/0.jpg')
    assert safe_thumbnail('http://i.ytimg.com/x') == ''
    assert safe_thumbnail('https://evil.example/x') == ''
