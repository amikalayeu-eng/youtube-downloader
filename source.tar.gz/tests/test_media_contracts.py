import shutil
import subprocess
import sys
import types
from pathlib import Path

import pytest

# The execution sandbox used for source review has FFmpeg but not redis/rq Python
# packages. These import-only stubs let us verify the media core there. Docker
# tests use the real pinned packages instead.
try:
    import redis  # noqa: F401
except ImportError:
    redis_mod = types.ModuleType("redis")
    class Redis:  # pragma: no cover - import shim only
        @classmethod
        def from_url(cls, *a, **kw):
            return cls()
    redis_mod.Redis = Redis
    sys.modules["redis"] = redis_mod
try:
    import rq  # noqa: F401
except ImportError:
    rq_mod = types.ModuleType("rq")
    class Queue:  # pragma: no cover - import shim only
        pass
    rq_mod.Queue = Queue
    sys.modules["rq"] = rq_mod

from app.downloader import audio_ffmpeg_command, video_ffmpeg_command, validate_audio, validate_video

FFMPEG = shutil.which("ffmpeg")
FFPROBE = shutil.which("ffprobe")
pytestmark = pytest.mark.skipif(not (FFMPEG and FFPROBE), reason="ffmpeg/ffprobe unavailable")


def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def test_audio_command_contract(tmp_path):
    src, mp3, wav = tmp_path / "src.m4a", tmp_path / "out.mp3", tmp_path / "out.wav"
    a = audio_ffmpeg_command(src, mp3, "mp3")
    assert ["-c:a", "libmp3lame"] == a[a.index("-c:a"):a.index("-c:a")+2]
    assert "320k" in a and "44100" in a and "2" in a
    b = audio_ffmpeg_command(src, wav, "wav")
    assert "pcm_s16le" in b and "44100" in b and "2" in b


def test_video_command_contract(tmp_path):
    cmd = video_ffmpeg_command(tmp_path/"v.webm", tmp_path/"a.m4a", tmp_path/"out.mp4", "medium")
    joined = " ".join(cmd)
    assert "-map 0:v:0 -map 1:a:0" in joined
    assert "-c:v libx264" in joined
    assert "-pix_fmt yuv420p" in joined
    assert "-c:a aac" in joined and "-b:a 192k" in joined
    assert "-movflags +faststart" in joined
    assert "scale=-2:min(720\\,ih)" in joined


def test_real_mp3_and_wav_validation(tmp_path):
    mp3 = tmp_path / "test.mp3"
    wav = tmp_path / "test.wav"
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1.2", "-ac", "2", "-ar", "44100", "-c:a", "libmp3lame", "-b:a", "320k", str(mp3)])
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1.2", "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", str(wav)])
    assert validate_audio(mp3, "mp3")["codec"] == "mp3"
    assert validate_audio(wav, "wav")["codec"] == "pcm_s16le"


def test_real_h264_aac_mp4_validation(tmp_path):
    out = tmp_path / "test.mp4"
    run([
        FFMPEG, "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=24:duration=1.5",
        "-f", "lavfi", "-i", "sine=frequency=880:duration=1.5",
        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "libx264", "-preset", "veryfast",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out),
    ])
    data = validate_video(out, 1.5)
    assert data["video_codec"] == "h264"
    assert data["audio_codec"] == "aac"
