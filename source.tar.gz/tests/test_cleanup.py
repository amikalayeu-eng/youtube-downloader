import time
from pathlib import Path

from app.config import settings
from app.storage import cleanup_local_storage


def test_stale_work_and_result_directories_are_deleted(tmp_path):
    old = settings.job_root
    object.__setattr__(settings, "job_root", tmp_path)
    for group in ("work", "results"):
        d = tmp_path / group / "j_test"
        d.mkdir(parents=True)
        (d / "junk.bin").write_bytes(b"x")
        (d / ".expires").write_text(str(int(time.time()) - 1), encoding="ascii")
    try:
        assert cleanup_local_storage() == 2
        assert not (tmp_path / "work" / "j_test").exists()
        assert not (tmp_path / "results" / "j_test").exists()
    finally:
        object.__setattr__(settings, "job_root", old)


def test_local_storage_delete_removes_published_result(tmp_path):
    from app.storage import LocalStorage

    old_root = settings.job_root
    object.__setattr__(settings, "job_root", tmp_path)
    try:
        source_dir = tmp_path / "work" / "j_delete"
        source_dir.mkdir(parents=True)
        source = source_dir / "final.mp3"
        source.write_bytes(b"media")
        st = LocalStorage(tmp_path)
        key, size = st.put("j_delete", source, "safe.mp3")
        assert size == 5
        assert st.local_path(key) is not None
        st.delete(key)
        assert st.local_path(key) is None
        assert not (tmp_path / "results" / "j_delete").exists()
    finally:
        object.__setattr__(settings, "job_root", old_root)
