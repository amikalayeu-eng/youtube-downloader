from app.states import JOB_STATES, TERMINAL_STATES, can_transition


def test_required_job_states_exist():
    assert {"queued", "analyzing", "downloading", "processing", "validating", "ready", "failed", "expired"} <= JOB_STATES


def test_normal_download_state_path_is_allowed():
    path = ["queued", "downloading", "processing", "validating", "ready", "expired"]
    assert all(can_transition(a, b) for a, b in zip(path, path[1:]))


def test_terminal_failure_cannot_restart():
    assert "failed" in TERMINAL_STATES
    assert not can_transition("failed", "downloading")
