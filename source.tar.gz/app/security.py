from __future__ import annotations

import hashlib
import re
import secrets
import urllib.parse
from typing import Optional

YOUTUBE_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
CONTROL_OR_FS = re.compile(r'[\x00-\x1f/\\:<>"|?*]')


def normalize_youtube_url(value: str) -> str:
    """Port of AudioERA 2.1.3 one-URL/one-video validation."""
    if not isinstance(value, str) or len(value) > 2048:
        raise ValueError("Enter a normal YouTube video URL.")
    try:
        parsed = urllib.parse.urlsplit(value.strip())
        port = parsed.port
    except (TypeError, ValueError):
        raise ValueError("Enter a normal YouTube video URL.") from None
    if parsed.scheme not in ("http", "https") or parsed.username or parsed.password or port not in (None, 80, 443):
        raise ValueError("Enter a normal YouTube video URL.")
    host = (parsed.hostname or "").lower()
    vid = ""
    if host in ("youtu.be", "www.youtu.be"):
        vid = parsed.path.strip("/")
    elif host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
        if parsed.path == "/watch":
            vid = urllib.parse.parse_qs(parsed.query).get("v", [""])[0]
        elif re.fullmatch(r"/(?:shorts|live|embed)/[^/]+/?", parsed.path):
            vid = parsed.path.split("/")[2]
    if not YOUTUBE_ID.fullmatch(vid):
        raise ValueError("Use one YouTube video URL, not a channel or playlist.")
    return f"https://www.youtube.com/watch?v={vid}"


def safe_filename(title: str, max_utf8_bytes: int = 180) -> str:
    safe = CONTROL_OR_FS.sub(" ", str(title or "")).strip(" .") or "YouTube Media"
    safe = re.sub(r"\s+", " ", safe)
    while len(safe.encode("utf-8")) > max_utf8_bytes:
        safe = safe[:-1]
    return safe or "YouTube Media"


def safe_thumbnail(url: Optional[str]) -> str:
    if not url:
        return ""
    try:
        p = urllib.parse.urlsplit(url)
    except Exception:
        return ""
    host = (p.hostname or "").lower()
    if p.scheme == "https" and (host == "i.ytimg.com" or host.endswith(".ytimg.com") or host == "img.youtube.com"):
        return url
    return ""


def new_public_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_urlsafe(18)}"


def new_session_id() -> str:
    return secrets.token_urlsafe(24)


def privacy_hash(value: str, salt: str) -> str:
    return hashlib.sha256((salt + "\0" + value).encode("utf-8", "ignore")).hexdigest()[:32]
