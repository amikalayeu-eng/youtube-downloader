from __future__ import annotations

import multiprocessing as mp
import os
import signal
import sys
import time
from pathlib import Path

from redis import Redis
from rq import Queue, Worker

from .config import settings
from .downloader import executable, js_runtime
from .logging_json import configure_logging
from .storage import cleanup_local_storage


def _run_worker(queue_name: str) -> None:
    connection = Redis.from_url(settings.redis_url)
    q = Queue(queue_name, connection=connection)
    worker = Worker([q], connection=connection, name=f"{queue_name}-{os.getpid()}")
    worker.work(with_scheduler=False)


def main() -> None:
    configure_logging()
    if not settings.load_test_fake_media:
        executable(settings.ffmpeg_path)
        executable(settings.ffprobe_path)
        executable(settings.yt_dlp_path)
        js_runtime()
    settings.job_root.mkdir(parents=True, exist_ok=True)
    cleanup_local_storage()
    procs: list[mp.Process] = []
    for _ in range(settings.analyze_workers):
        p = mp.Process(target=_run_worker, args=("analysis",), daemon=False)
        p.start(); procs.append(p)
    for _ in range(settings.download_workers):
        p = mp.Process(target=_run_worker, args=("downloads",), daemon=False)
        p.start(); procs.append(p)

    def terminate_children() -> None:
        for p in procs:
            if p.is_alive():
                p.terminate()
        for p in procs:
            p.join(timeout=8)

    def stop(*_):
        terminate_children()
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    # If any queue worker process exits unexpectedly, fail the container so the
    # Docker restart policy restores the complete configured worker pool.
    while True:
        dead = [p for p in procs if not p.is_alive()]
        if dead:
            bad_codes = [p.exitcode for p in dead]
            terminate_children()
            sys.exit(1 if any(code not in (0, None) for code in bad_codes) else 0)
        time.sleep(1)


if __name__ == "__main__":
    main()
