from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path


def _int(name: str, default: int, minimum: int = 0) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc
    if value < minimum:
        raise RuntimeError(f"{name} must be >= {minimum}")
    return value


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    redis_url: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
    job_root: Path = Path(os.getenv("JOB_ROOT", "/tmp/audioera-jobs")).resolve()
    frontend_dir: Path = Path(os.getenv("FRONTEND_DIR", str(Path(__file__).resolve().parent.parent / "frontend"))).resolve()
    public_base_url: str = os.getenv("PUBLIC_BASE_URL", "http://localhost:8080").rstrip("/")
    trust_proxy: bool = _bool("TRUST_PROXY", False)
    privacy_salt: str = os.getenv("PRIVACY_SALT", "change-me-in-production")

    analyze_workers: int = _int("ANALYZE_WORKERS", 2, 1)
    download_workers: int = _int("DOWNLOAD_WORKERS", 2, 1)
    ffmpeg_workers: int = _int("FFMPEG_WORKERS", 2, 1)
    max_queue_size: int = _int("MAX_QUEUE_SIZE", 100, 1)
    max_file_size_mb: int = _int("MAX_FILE_SIZE_MB", 750, 10)
    max_source_file_size_mb: int = _int("MAX_SOURCE_FILE_SIZE_MB", 1500, 20)
    max_duration_seconds: int = _int("MAX_DURATION_SECONDS", 3600, 30)
    job_timeout_seconds: int = _int("JOB_TIMEOUT_SECONDS", 7200, 60)
    analyze_timeout_seconds: int = _int("ANALYZE_TIMEOUT_SECONDS", 180, 20)
    file_ttl_seconds: int = _int("FILE_TTL_SECONDS", 1800, 60)
    post_download_ttl_seconds: int = _int("POST_DOWNLOAD_TTL_SECONDS", 900, 60)
    analysis_ttl_seconds: int = _int("ANALYSIS_TTL_SECONDS", 900, 60)
    cleanup_interval_seconds: int = _int("CLEANUP_INTERVAL_SECONDS", 300, 30)
    disk_high_watermark_percent: int = _int("DISK_HIGH_WATERMARK_PERCENT", 85, 50)
    disk_reserve_mb: int = _int("DISK_RESERVE_MB", 1024, 128)
    max_retries: int = _int("MAX_RETRIES", 3, 0)

    session_concurrent_jobs: int = _int("SESSION_CONCURRENT_JOBS", 2, 1)
    ip_concurrent_jobs: int = _int("IP_CONCURRENT_JOBS", 4, 1)
    analyze_per_minute: int = _int("ANALYZE_PER_MINUTE", 20, 1)
    jobs_per_hour: int = _int("JOBS_PER_HOUR", 30, 1)
    events_per_minute: int = _int("EVENTS_PER_MINUTE", 120, 1)
    request_body_limit: int = _int("REQUEST_BODY_LIMIT", 8192, 1024)

    load_test_fake_media: bool = _bool("LOAD_TEST_FAKE_MEDIA", False)

    storage_backend: str = os.getenv("STORAGE_BACKEND", "local").lower()
    s3_endpoint_url: str = os.getenv("S3_ENDPOINT_URL", "")
    s3_region: str = os.getenv("S3_REGION", "")
    s3_bucket: str = os.getenv("S3_BUCKET", "")
    s3_access_key_id: str = os.getenv("S3_ACCESS_KEY_ID", "")
    s3_secret_access_key: str = os.getenv("S3_SECRET_ACCESS_KEY", "")

    yt_dlp_path: str = os.getenv("YT_DLP_PATH", "yt-dlp")
    ffmpeg_path: str = os.getenv("FFMPEG_PATH", "ffmpeg")
    ffprobe_path: str = os.getenv("FFPROBE_PATH", "ffprobe")
    js_runtime_path: str = os.getenv("JS_RUNTIME_PATH", "")
    yt_dlp_extractor_args: str = os.getenv("YT_DLP_EXTRACTOR_ARGS", "").strip()
    yt_dlp_plugin_dirs: str = os.getenv("YT_DLP_PLUGIN_DIRS", "").strip()

    @property
    def max_file_size_bytes(self) -> int:
        return self.max_file_size_mb * 1024 * 1024

    @property
    def max_source_file_size_bytes(self) -> int:
        return self.max_source_file_size_mb * 1024 * 1024

    @property
    def disk_reserve_bytes(self) -> int:
        return self.disk_reserve_mb * 1024 * 1024


settings = Settings()
