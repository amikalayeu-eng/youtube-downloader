"""Public job-state contract shared by API/tests/docs."""
JOB_STATES = frozenset({
    "queued", "analyzing", "downloading", "processing", "validating",
    "ready", "failed", "expired", "cancelled",
})
TERMINAL_STATES = frozenset({"ready", "failed", "expired", "cancelled"})

ALLOWED_TRANSITIONS = {
    "queued": {"analyzing", "downloading", "failed", "cancelled", "expired"},
    "analyzing": {"ready", "failed", "cancelled", "expired"},
    "downloading": {"processing", "failed", "cancelled", "expired"},
    "processing": {"validating", "failed", "cancelled", "expired"},
    "validating": {"ready", "failed", "cancelled", "expired"},
    "ready": {"expired"},
    "failed": set(),
    "expired": set(),
    "cancelled": set(),
}


def can_transition(old: str, new: str) -> bool:
    return new == old or new in ALLOWED_TRANSITIONS.get(old, set())
