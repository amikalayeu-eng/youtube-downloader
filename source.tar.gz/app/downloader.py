from __future__ import annotations

import json
import math
import os
import logging
import queue
import signal
import threading
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time
from typing import Callable

from .config import settings
from .redis_client import redis_conn
from .security import normalize_youtube_url, safe_filename, safe_thumbnail

Progress = Callable[[str, str, str], None]
log = logging.getLogger("audioera.media")


class DownloadError(RuntimeError):
    pass


class Cancelled(DownloadError):
    pass


def executable(path_or_name: str) -> str:
    found = shutil.which(path_or_name) if os.path.sep not in path_or_name else path_or_name
    if not found or not Path(found).is_file() or not os.access(found, os.X_OK):
        raise RuntimeError(f"Required executable not found: {path_or_name}")
    return str(found)


def _runtime_version(path: str) -> tuple[int, int, int]:
    try:
        proc = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5, check=False)
        text = (proc.stdout or proc.stderr or "").splitlines()[0]
    except Exception as exc:
        raise RuntimeError(f"Could not query JavaScript runtime: {path}") from exc
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", text)
    if not match:
        raise RuntimeError(f"Could not parse JavaScript runtime version: {text[:120]}")
    return tuple(int(x) for x in match.groups())


def js_runtime() -> tuple[str, str]:
    """Return a yt-dlp supported JS runtime, preferring Deno as upstream recommends."""
    candidates: list[tuple[str, str]] = []
    configured = settings.js_runtime_path.strip()
    if configured:
        runtime_exec = executable(configured)
        base = Path(runtime_exec).name.lower()
        if "deno" in base:
            candidates.append(("deno", runtime_exec))
        elif base in {"node", "nodejs"} or "node" in base:
            candidates.append(("node", runtime_exec))
        else:
            raise RuntimeError("JS_RUNTIME_PATH must point to Deno or Node.")
    else:
        for name in ("deno", "node"):
            found = shutil.which(name)
            if found:
                candidates.append((name, found))

    minimum = {"deno": (2, 3, 0), "node": (22, 0, 0)}
    failures: list[str] = []
    for name, path in candidates:
        try:
            version = _runtime_version(path)
        except RuntimeError as exc:
            failures.append(str(exc))
            continue
        if version >= minimum[name]:
            return name, path
        failures.append(f"{name} {'.'.join(map(str, version))} is below supported minimum {'.'.join(map(str, minimum[name]))}")
    detail = "; ".join(failures) if failures else "no Deno or Node executable found"
    raise RuntimeError(f"A supported yt-dlp JavaScript runtime is required ({detail}).")


def yt_dlp_base() -> list[str]:
    runtime_name, runtime_exec = js_runtime()
    args = [
        executable(settings.yt_dlp_path),
        "--ignore-config",
        "--no-playlist",
        "--no-overwrites",
        "--no-colors",
        "--socket-timeout", "30",
        "--retries", str(settings.max_retries),
        "--js-runtimes", f"{runtime_name}:{runtime_exec}",
    ]
    # These values are operator-controlled environment settings, never user input.
    if settings.yt_dlp_plugin_dirs:
        args += ["--plugin-dirs", settings.yt_dlp_plugin_dirs]
    if settings.yt_dlp_extractor_args:
        args += ["--extractor-args", settings.yt_dlp_extractor_args]
    return args


def _cancel_requested(job_id: str | None) -> bool:
    return bool(job_id and redis_conn().get(f"audioera:cancel:{job_id}"))


def _stop(proc: subprocess.Popen[str] | None) -> None:
    if not proc or proc.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(proc.pid, signal.SIGTERM)
        else:
            proc.terminate()
    except (ProcessLookupError, PermissionError):
        pass
    try:
        proc.wait(timeout=5)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        if os.name == "posix":
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError):
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass


def _popen(argv: list[str]) -> subprocess.Popen[str]:
    return subprocess.Popen(
        argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        start_new_session=(os.name == "posix"),
    )


def _remaining(deadline: float, cap: int | None = None) -> int:
    seconds = max(1, int(deadline - time.monotonic()))
    if cap is not None:
        seconds = min(seconds, cap)
    return seconds


def _process_name(args: list[str | Path]) -> str:
    name = Path(str(args[0])).name.lower() if args else "process"
    if "yt-dlp" in name:
        return "yt-dlp"
    if "ffmpeg" in name:
        return "ffmpeg"
    if "ffprobe" in name:
        return "ffprobe"
    return name or "process"


def run_cancellable(args: list[str | Path], *, job_id: str | None = None, timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    """Run without a shell, while retaining cancel/timeout even if child pipes are quiet/full."""
    timeout = timeout or settings.job_timeout_seconds
    argv = [str(x) for x in args]
    proc = _popen(argv)
    holder: dict[str, object] = {}

    def communicate() -> None:
        try:
            holder["data"] = proc.communicate()
        except BaseException as exc:  # propagated in caller thread
            holder["error"] = exc

    thread = threading.Thread(target=communicate, name=f"proc-{proc.pid}", daemon=True)
    thread.start()
    started = time.monotonic()
    try:
        while thread.is_alive():
            if _cancel_requested(job_id):
                _stop(proc)
                thread.join(timeout=6)
                raise Cancelled("The operation was cancelled.")
            if time.monotonic() - started > timeout:
                _stop(proc)
                thread.join(timeout=6)
                raise DownloadError("Processing timeout exceeded.")
            thread.join(timeout=0.1)
        if "error" in holder:
            raise holder["error"]  # type: ignore[misc]
        out, err = holder.get("data", ("", ""))  # type: ignore[misc]
        exit_code = int(proc.returncode or 0)
        log.info("process_exit", extra={"job_id": job_id or "", "process": _process_name(args), "exit_status": exit_code})
        if exit_code:
            raise DownloadError(_friendly_process_error(str(err)))
        return subprocess.CompletedProcess(argv, exit_code, str(out), str(err))
    finally:
        _stop(proc)


def _friendly_process_error(stderr: str) -> str:
    lower = (stderr or "").lower()
    if "private video" in lower or "sign in if you've been granted access" in lower:
        return "This video is private."
    if "video unavailable" in lower or "not available" in lower:
        return "This video is unavailable."
    if "not available in your country" in lower or "geo" in lower and "restrict" in lower:
        return "This video is not available from the server region."
    if "sign in to confirm your age" in lower or "age-restricted" in lower:
        return "Age-restricted videos are not supported in this MVP."
    if "requested format is not available" in lower:
        return "The requested media format is not available for this video."
    if "confirm you’re not a bot" in lower or "confirm you're not a bot" in lower:
        return "YouTube is currently challenging this server. Try again later."
    if "http error 429" in lower or "too many requests" in lower:
        return "YouTube temporarily rate-limited this server. Try again later."
    if "http error 403" in lower:
        return "YouTube refused this media request from the server."
    return "Media processing failed. Check server logs for the technical cause."


def analyze_url(value: str, *, job_id: str | None = None) -> dict:
    url = normalize_youtube_url(value)
    result = run_cancellable(
        [*yt_dlp_base(), "--skip-download", "--dump-single-json", "--", url],
        job_id=job_id,
        timeout=settings.analyze_timeout_seconds,
    )
    try:
        info = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise DownloadError("YouTube metadata response was invalid.") from exc
    if info.get("is_live"):
        raise DownloadError("Live streams are not supported. Wait until the stream has ended.")
    duration = float(info.get("duration") or 0)
    if not math.isfinite(duration) or duration <= 0:
        raise DownloadError("The video duration could not be verified.")
    if duration > settings.max_duration_seconds:
        raise DownloadError(f"Video is longer than the {settings.max_duration_seconds // 60}-minute limit.")
    title = str(info.get("title") or info.get("id") or "YouTube Media")
    thumb = safe_thumbnail(info.get("thumbnail"))
    return {
        "url": url,
        "video_id": str(info.get("id") or ""),
        "title": title,
        "safe_title": safe_filename(title),
        "duration": duration,
        "thumbnail": thumb,
    }


def _download_stream(
    *,
    args: list[str],
    url: str,
    stage: Path,
    selector: str,
    prefix: str,
    label: str,
    job_id: str,
    progress: Progress,
    deadline: float,
) -> Path:
    cmd = [
        *args,
        "-f", selector,
        "--max-filesize", str(settings.max_source_file_size_bytes),
        "--newline",
        "--progress",
        "--progress-template", "download:PROGRESS %(progress._percent_str)s",
        "-o", str(stage / f"{prefix}.%(ext)s"),
        "--", url,
    ]
    proc = _popen([str(x) for x in cmd])
    out_q: queue.Queue[str] = queue.Queue()
    stderr_parts: list[str] = []
    stdout_done = threading.Event()
    stderr_done = threading.Event()

    def read_stdout() -> None:
        try:
            if proc.stdout:
                for line in proc.stdout:
                    out_q.put(line)
        finally:
            stdout_done.set()

    def read_stderr() -> None:
        try:
            if proc.stderr:
                # Keep only a bounded diagnostic tail so a noisy child cannot grow memory indefinitely.
                tail = ""
                while True:
                    chunk = proc.stderr.read(4096)
                    if not chunk:
                        break
                    tail = (tail + chunk)[-32768:]
                stderr_parts.append(tail)
        finally:
            stderr_done.set()

    t_out = threading.Thread(target=read_stdout, name=f"ytdlp-out-{proc.pid}", daemon=True)
    t_err = threading.Thread(target=read_stderr, name=f"ytdlp-err-{proc.pid}", daemon=True)
    t_out.start(); t_err.start()
    started = time.monotonic()
    try:
        while True:
            if _cancel_requested(job_id):
                _stop(proc)
                raise Cancelled("The operation was cancelled.")
            if time.monotonic() >= deadline:
                _stop(proc)
                raise DownloadError("Job processing timeout exceeded.")
            try:
                line = out_q.get(timeout=0.2)
            except queue.Empty:
                line = ""
            if line.startswith("PROGRESS "):
                pct = line[9:].strip().replace("%", "").strip()
                if re.fullmatch(r"\d+(?:\.\d+)?", pct):
                    progress("downloading", label, pct)
            if proc.poll() is not None and stdout_done.is_set() and out_q.empty():
                break
        t_out.join(timeout=2); t_err.join(timeout=2)
        stderr = "".join(stderr_parts)
        exit_code = int(proc.returncode or 0)
        log.info("process_exit", extra={"job_id": job_id, "process": "yt-dlp", "exit_status": exit_code})
        if exit_code:
            raise DownloadError(_friendly_process_error(stderr))
    finally:
        _stop(proc)
        if proc.stdout:
            proc.stdout.close()
        if proc.stderr:
            proc.stderr.close()
    files = [p for p in stage.iterdir() if p.is_file() and p.name.startswith(prefix + ".") and not p.name.endswith((".part", ".ytdl"))]
    if not files:
        raise DownloadError("YouTube did not produce the requested media stream.")
    source = max(files, key=lambda p: p.stat().st_size)
    if source.stat().st_size > settings.max_source_file_size_bytes:
        raise DownloadError("The source media exceeds the configured size limit.")
    return source


def _ffprobe(path: Path, *, job_id: str | None = None, timeout: int = 120) -> dict:
    result = run_cancellable([
        executable(settings.ffprobe_path), "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)
    ], job_id=job_id, timeout=timeout)
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise DownloadError("ffprobe returned invalid JSON.") from exc


def _audio_stream_and_duration(path: Path, *, job_id: str | None = None, timeout: int = 120) -> tuple[dict, float]:
    data = _ffprobe(path, job_id=job_id, timeout=timeout)
    streams = [s for s in data.get("streams", []) if s.get("codec_type") == "audio"]
    if len(streams) != 1:
        raise DownloadError("The result must contain exactly one audio stream.")
    duration = float(data.get("format", {}).get("duration") or 0)
    if not math.isfinite(duration) or duration <= 0:
        raise DownloadError("The result duration is invalid.")
    return streams[0], duration


def validate_audio(path: Path, kind: str, *, job_id: str | None = None, timeout: int = 120) -> dict:
    stream, duration = _audio_stream_and_duration(path, job_id=job_id, timeout=timeout)
    expected_codec = "mp3" if kind == "mp3" else "pcm_s16le"
    if stream.get("codec_name") != expected_codec:
        raise DownloadError(f"{kind.upper()} codec validation failed.")
    if int(stream.get("sample_rate") or 0) != 44100 or int(stream.get("channels") or 0) != 2:
        raise DownloadError(f"{kind.upper()} sample-rate/channel validation failed.")
    if kind == "mp3":
        bitrate = int(stream.get("bit_rate") or 0)
        if abs(bitrate - 320000) > 2000:
            raise DownloadError("MP3 320 kbps validation failed.")
    if path.stat().st_size <= 0:
        raise DownloadError("The result file is empty.")
    return {"duration": duration, "codec": stream.get("codec_name")}


def validate_video(path: Path, expected_duration: float, *, job_id: str | None = None, timeout: int = 120) -> dict:
    data = _ffprobe(path, job_id=job_id, timeout=timeout)
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    fmt = data.get("format", {})
    duration = float(fmt.get("duration") or 0)
    if not video or video.get("codec_name") != "h264":
        raise DownloadError("MP4 H.264 video validation failed.")
    if not audio or audio.get("codec_name") != "aac":
        raise DownloadError("MP4 AAC audio validation failed.")
    if "mp4" not in str(fmt.get("format_name") or ""):
        raise DownloadError("MP4 container validation failed.")
    if not math.isfinite(duration) or duration <= 0 or abs(duration - expected_duration) > max(3.0, expected_duration * 0.03):
        raise DownloadError("MP4 duration validation failed.")
    if path.stat().st_size <= 0:
        raise DownloadError("The result file is empty.")
    return {"duration": duration, "video_codec": "h264", "audio_codec": "aac"}


_FFMPEG_ACQUIRE = """
local key=KEYS[1]
local now=tonumber(ARGV[1])
local expiry=tonumber(ARGV[2])
local limit=tonumber(ARGV[3])
local token=ARGV[4]
redis.call('ZREMRANGEBYSCORE',key,'-inf',now)
if redis.call('ZCARD',key) < limit then
  redis.call('ZADD',key,expiry,token)
  redis.call('EXPIRE',key,180)
  return 1
end
return 0
"""

_FFMPEG_REFRESH = """
local key=KEYS[1]
local token=ARGV[1]
local expiry=tonumber(ARGV[2])
if redis.call('ZSCORE',key,token) then
  redis.call('ZADD',key,expiry,token)
  redis.call('EXPIRE',key,180)
  return 1
end
return 0
"""


class FfmpegSlot:
    """Global Redis-backed FFmpeg concurrency lease.

    Leases are deliberately short and heartbeated. If an RQ work horse is killed
    hard, its slot returns automatically instead of remaining reserved for the
    entire multi-hour job timeout.
    """
    lease_seconds = 90
    heartbeat_seconds = 30

    def __init__(self, job_id: str, deadline: float):
        self.job_id = job_id
        self.deadline = deadline
        self.token = f"{job_id}:{os.getpid()}:{time.time_ns()}"
        self.key = "audioera:ffmpeg:leases"
        self._heartbeat_stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None

    def _start_heartbeat(self) -> None:
        def beat() -> None:
            while not self._heartbeat_stop.wait(self.heartbeat_seconds):
                try:
                    now_ms = int(time.time() * 1000)
                    expiry_ms = now_ms + self.lease_seconds * 1000
                    ok = redis_conn().eval(_FFMPEG_REFRESH, 1, self.key, self.token, expiry_ms)
                    if not ok:
                        return
                except Exception:
                    # Redis connection trouble is handled by the normal job path;
                    # a missed heartbeat causes the lease to fail safe and expire.
                    return

        self._heartbeat_thread = threading.Thread(
            target=beat, name=f"ffmpeg-lease-{os.getpid()}", daemon=True,
        )
        self._heartbeat_thread.start()

    def __enter__(self):
        r = redis_conn()
        while time.monotonic() < self.deadline:
            if _cancel_requested(self.job_id):
                raise Cancelled("The operation was cancelled.")
            now_ms = int(time.time() * 1000)
            expiry_ms = now_ms + self.lease_seconds * 1000
            ok = r.eval(_FFMPEG_ACQUIRE, 1, self.key, now_ms, expiry_ms, settings.ffmpeg_workers, self.token)
            if ok:
                self._start_heartbeat()
                return self
            time.sleep(0.25)
        raise DownloadError("Processing capacity is busy for too long.")

    def __exit__(self, exc_type, exc, tb):
        self._heartbeat_stop.set()
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=1)
        try:
            redis_conn().zrem(self.key, self.token)
        except Exception:
            pass


def audio_ffmpeg_command(source: Path, final: Path, kind: str) -> list[str]:
    cmd = [executable(settings.ffmpeg_path), "-hide_banner", "-nostdin", "-y", "-v", "error", "-i", str(source), "-vn", "-map_metadata", "-1"]
    if kind == "mp3":
        return cmd + ["-c:a", "libmp3lame", "-b:a", "320k", "-ar", "44100", "-ac", "2", str(final)]
    if kind == "wav":
        return cmd + ["-c:a", "pcm_s16le", "-ar", "44100", "-ac", "2", str(final)]
    raise DownloadError("Unknown audio output format.")


def video_ffmpeg_command(video: Path, audio: Path, final: Path, quality: str) -> list[str]:
    vf = {"low": "scale=-2:min(480\\,ih)", "medium": "scale=-2:min(720\\,ih)", "maximum": None}[quality]
    cmd = [
        executable(settings.ffmpeg_path), "-hide_banner", "-nostdin", "-y", "-v", "error",
        "-i", str(video), "-i", str(audio), "-map", "0:v:0", "-map", "1:a:0", "-map_metadata", "-1",
    ]
    if vf:
        cmd += ["-vf", vf]
    return cmd + [
        "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(final),
    ]


def ensure_disk_capacity(kind: str) -> None:
    """Conservative guard against concurrent workers exhausting the shared temp volume."""
    settings.job_root.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(settings.job_root)
    if usage.total and int((usage.used / usage.total) * 100) >= settings.disk_high_watermark_percent:
        raise DownloadError("Temporary storage is near capacity. Try again later.")
    per_job = settings.max_source_file_size_bytes + settings.max_file_size_bytes
    if kind == "video":
        per_job += settings.max_source_file_size_bytes  # separate video + audio inputs
    conservative_need = per_job * settings.download_workers + settings.disk_reserve_bytes
    if usage.free < conservative_need:
        raise DownloadError("Not enough temporary disk capacity for the configured worker limits.")


def download_media(
    *,
    url: str,
    title: str,
    duration: float,
    kind: str,
    quality: str,
    job_id: str,
    progress: Progress,
) -> tuple[Path, str, dict]:
    url = normalize_youtube_url(url)
    kind = str(kind or "mp3").lower()
    quality = str(quality or "maximum").lower()
    if kind not in {"mp3", "wav", "video"}:
        raise DownloadError("Unknown output format.")
    if quality not in {"low", "medium", "maximum"}:
        quality = "maximum"
    ensure_disk_capacity(kind)
    executable(settings.ffmpeg_path)
    executable(settings.ffprobe_path)
    args = yt_dlp_base()
    deadline = time.monotonic() + settings.job_timeout_seconds

    work_parent = settings.job_root / "work"
    work_parent.mkdir(parents=True, exist_ok=True)
    job_dir = work_parent / job_id
    job_dir.mkdir(parents=False, exist_ok=False)
    (job_dir / ".expires").write_text(str(int(time.time()) + settings.job_timeout_seconds + 300), encoding="ascii")

    try:
        if kind in {"mp3", "wav"}:
            source = _download_stream(
                args=args, url=url, stage=job_dir, selector="bestaudio/best", prefix="source",
                label="Downloading audio", job_id=job_id, progress=progress, deadline=deadline,
            )
            ext = f".{kind}"
            final = job_dir / f"final{ext}"
            progress("processing", f"Converting {kind.upper()}", "")
            with FfmpegSlot(job_id, deadline):
                run_cancellable(audio_ffmpeg_command(source, final, kind), job_id=job_id, timeout=_remaining(deadline))
            progress("validating", f"Validating {kind.upper()}", "")
            details = validate_audio(final, kind, job_id=job_id, timeout=_remaining(deadline, 120))
            filename = safe_filename(title) + ext
        else:
            selector = {
                "low": "bestvideo[height<=480]/bestvideo",
                "medium": "bestvideo[height<=720]/bestvideo",
                "maximum": "bestvideo",
            }[quality]
            video = _download_stream(
                args=args, url=url, stage=job_dir, selector=selector, prefix="video",
                label="Downloading video", job_id=job_id, progress=progress, deadline=deadline,
            )
            audio = _download_stream(
                args=args, url=url, stage=job_dir, selector="bestaudio", prefix="audio",
                label="Downloading audio", job_id=job_id, progress=progress, deadline=deadline,
            )
            final = job_dir / "final.mp4"
            progress("processing", "Preparing MP4", "")
            with FfmpegSlot(job_id, deadline):
                run_cancellable(video_ffmpeg_command(video, audio, final, quality), job_id=job_id, timeout=_remaining(deadline))
            progress("validating", "Validating MP4", "")
            details = validate_video(final, duration, job_id=job_id, timeout=_remaining(deadline, 120))
            filename = safe_filename(title) + ".mp4"

        if final.stat().st_size > settings.max_file_size_bytes:
            raise DownloadError("The finished file exceeds the configured size limit.")
        return final, filename, details
    except Exception:
        raise
