from __future__ import annotations

import json
import logging
import shutil
import time
import traceback
from pathlib import Path

from .config import settings
from .logging_json import configure_logging
from .downloader import Cancelled, DownloadError, analyze_url, download_media
from .redis_client import get_hash, set_hash, update_hash, redis_conn
from .storage import storage

configure_logging()
log = logging.getLogger("audioera.worker")


def _now() -> str:
    return str(int(time.time()))


def _event(name: str, **fields) -> None:
    r = redis_conn()
    pipe = r.pipeline()
    pipe.incr(f"audioera:metric:{name}")
    if fields.get("format"):
        pipe.incr(f"audioera:metric:{name}:format:{fields['format']}")
    if fields.get("quality"):
        pipe.incr(f"audioera:metric:{name}:quality:{fields['quality']}")
    pipe.lpush("audioera:events", json.dumps({"event": name, "ts": int(time.time()), **fields}, ensure_ascii=False))
    pipe.ltrim("audioera:events", 0, 4999)
    pipe.execute()


def analyze_task(analysis_id: str, url: str) -> dict:
    started = time.time()
    log.info("analysis_started", extra={"job_id": analysis_id, "status": "analyzing"})
    update_hash("analysis", analysis_id, ttl=settings.analysis_ttl_seconds, status="analyzing", updated_at=_now())
    try:
        if settings.load_test_fake_media:
            from .security import normalize_youtube_url
            time.sleep(0.03)
            canonical = normalize_youtube_url(url)
            data = {"url": canonical, "video_id": canonical.rsplit("=", 1)[-1], "title": "Load Test Video", "safe_title": "Load Test Video", "duration": 120.0, "thumbnail": ""}
        else:
            data = analyze_url(url, job_id=analysis_id)
        update_hash(
            "analysis", analysis_id, ttl=settings.analysis_ttl_seconds,
            status="ready", updated_at=_now(), title=data["title"], safe_title=data["safe_title"],
            duration=data["duration"], thumbnail=data["thumbnail"], video_id=data["video_id"], url=data["url"],
        )
        _event("analyze_success")
        log.info("analysis_ready", extra={"job_id": analysis_id, "status": "ready", "duration": data["duration"], "processing_time": round(time.time() - started, 3)})
        return data
    except Exception as exc:
        update_hash("analysis", analysis_id, ttl=settings.analysis_ttl_seconds, status="failed", updated_at=_now(), error=str(exc)[:1200])
        _event("analyze_failed", error_category=type(exc).__name__)
        log.warning("analysis_failed", extra={"job_id": analysis_id, "status": "failed", "error_category": type(exc).__name__, "processing_time": round(time.time() - started, 3)})
        raise
    finally:
        redis_conn().delete(f"audioera:cancel:{analysis_id}")
        redis_conn().incrbyfloat("audioera:metric:analyze_seconds_total", time.time() - started)


def download_task(job_id: str, analysis_id: str, kind: str, quality: str) -> dict:
    started = time.time()
    log.info("job_started", extra={"job_id": job_id, "status": "downloading", "format": kind, "quality": quality})
    r = redis_conn()

    def cancel_requested() -> bool:
        current = get_hash("job", job_id)
        return current.get("status") == "cancelled" or bool(r.get(f"audioera:cancel:{job_id}"))

    def progress(state: str, label: str, percent: str) -> None:
        if cancel_requested():
            raise Cancelled("The download was cancelled.")
        update_hash(
            "job", job_id, ttl=settings.file_ttl_seconds + settings.job_timeout_seconds,
            status=state, updated_at=_now(), stage=label, progress=percent,
        )

    try:
        if cancel_requested():
            raise Cancelled("The download was cancelled.")

        analysis = get_hash("analysis", analysis_id)
        if not analysis or analysis.get("status") != "ready":
            raise DownloadError("Analysis metadata expired. Analyze the URL again.")

        update_hash(
            "job", job_id, ttl=settings.file_ttl_seconds + settings.job_timeout_seconds,
            status="downloading", updated_at=_now(), stage="Starting download",
        )

        if settings.load_test_fake_media:
            progress("downloading", "Synthetic queue test", "50")
            time.sleep(0.05)
            if cancel_requested():
                raise Cancelled("The download was cancelled.")
            work = settings.job_root / "work" / job_id
            work.mkdir(parents=True, exist_ok=True)
            (work / ".expires").write_text(str(int(time.time()) + 300), encoding="ascii")
            ext = ".mp4" if kind == "video" else f".{kind}"
            final = work / ("final" + ext)
            final.write_bytes(("AUDIOERA LOAD TEST " + job_id).encode("utf-8"))
            filename = "Load Test Video" + ext
            details = {"synthetic": True}
        else:
            final, filename, details = download_media(
                url=analysis["url"], title=analysis["title"], duration=float(analysis["duration"]),
                kind=kind, quality=quality, job_id=job_id, progress=progress,
            )

        # Cancellation wins over publication, including the small window after
        # ffprobe succeeds but before storage.put() makes the result downloadable.
        if cancel_requested():
            raise Cancelled("The download was cancelled.")

        result_storage = storage()
        key, size = result_storage.put(job_id, final, filename)
        if cancel_requested():
            try:
                result_storage.delete(key)
            finally:
                raise Cancelled("The download was cancelled.")

        update_hash(
            "job", job_id, ttl=settings.file_ttl_seconds,
            status="ready", updated_at=_now(), ready_at=_now(), stage="Ready", progress="",
            file_name=filename, storage_key=key, output_size=size, media_details=details,
        )
        _event("download_success", format=kind, quality=quality if kind == "video" else "")
        log.info(
            "job_ready",
            extra={
                "job_id": job_id, "status": "ready", "format": kind, "quality": quality,
                "duration": float(analysis["duration"]), "output_size": size,
                "processing_time": round(time.time() - started, 3),
            },
        )
        return {"file_name": filename, "storage_key": key, "size": size}

    except Cancelled:
        update_hash(
            "job", job_id, ttl=settings.file_ttl_seconds,
            status="cancelled", updated_at=_now(), stage="Cancelled", progress="",
            error="The download was cancelled.", error_category="Cancelled",
        )
        _event("download_cancelled", format=kind, quality=quality if kind == "video" else "")
        log.info(
            "job_cancelled",
            extra={
                "job_id": job_id, "status": "cancelled", "format": kind, "quality": quality,
                "processing_time": round(time.time() - started, 3),
            },
        )
        # A user cancellation is a terminal product state, not an RQ failure.
        return {"cancelled": True}

    except Exception as exc:
        category = "AnalysisExpired" if isinstance(exc, DownloadError) and str(exc).startswith("Analysis metadata expired") else type(exc).__name__
        update_hash(
            "job", job_id, ttl=settings.file_ttl_seconds,
            status="failed", updated_at=_now(), stage="Failed", progress="",
            error=str(exc)[:1200], error_category=category,
        )
        _event("download_failed", format=kind, error_category=category)
        log.warning(
            "job_failed",
            extra={
                "job_id": job_id, "status": "failed", "format": kind, "quality": quality,
                "error_category": category, "processing_time": round(time.time() - started, 3),
            },
        )
        raise

    finally:
        shutil.rmtree(settings.job_root / "work" / job_id, ignore_errors=True)
        r.delete(f"audioera:cancel:{job_id}")
        elapsed = time.time() - started
        job = get_hash("job", job_id)
        if job.get("session_hash"):
            r.srem(f"audioera:active:session:{job['session_hash']}", job_id)
        if job.get("ip_hash"):
            r.srem(f"audioera:active:ip:{job['ip_hash']}", job_id)
        r.incrbyfloat("audioera:metric:processing_seconds_total", elapsed)
        r.incr("audioera:metric:jobs_processed")
