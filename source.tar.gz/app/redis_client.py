from __future__ import annotations

import json
import time
from typing import Any

from redis import Redis
from rq import Queue

from .config import settings


def redis_conn() -> Redis:
    return Redis.from_url(settings.redis_url, decode_responses=True, socket_connect_timeout=3, socket_timeout=5)


def rq_conn() -> Redis:
    return Redis.from_url(settings.redis_url, decode_responses=False, socket_connect_timeout=3, socket_timeout=5)


def queue(name: str) -> Queue:
    return Queue(name, connection=rq_conn(), default_timeout=settings.job_timeout_seconds)


def key(kind: str, ident: str) -> str:
    return f"audioera:{kind}:{ident}"


def set_hash(kind: str, ident: str, values: dict[str, Any], ttl: int) -> None:
    r = redis_conn()
    data = {k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list, bool)) or v is None else str(v) for k, v in values.items()}
    pipe = r.pipeline()
    pipe.hset(key(kind, ident), mapping=data)
    pipe.expire(key(kind, ident), ttl)
    pipe.execute()


def update_hash(kind: str, ident: str, ttl: int | None = None, **values: Any) -> None:
    r = redis_conn()
    data = {k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list, bool)) or v is None else str(v) for k, v in values.items()}
    pipe = r.pipeline()
    pipe.hset(key(kind, ident), mapping=data)
    if ttl:
        pipe.expire(key(kind, ident), ttl)
    pipe.execute()


def get_hash(kind: str, ident: str) -> dict[str, str]:
    return redis_conn().hgetall(key(kind, ident))


def rate_limit(bucket: str, subject: str, limit: int, window_seconds: int) -> tuple[bool, int]:
    r = redis_conn()
    window = int(time.time()) // window_seconds
    k = f"audioera:rate:{bucket}:{subject}:{window}"
    pipe = r.pipeline()
    pipe.incr(k)
    pipe.expire(k, window_seconds + 5)
    count, _ = pipe.execute()
    return int(count) <= limit, max(0, limit - int(count))
